title: angular上手
speaker: gym

[slide]
#angularjs上手

分享人: 郭艳明

[slide]
##概要

1. angular页面的创建

2. angular应用之表单校验

3. angular的启动流程

[slide]
##一、ng页面的创建
1. 一个左侧入口对应一个单页面应用

2. 单页面应用所有的代码挂载在一个模块下

[slide]
##ng页面的创建-ctrl
```js
	var controlFns = {
	'index' : function(spid){
		var php = {
			'back' : 'shop::/shopadmin/shop_shutdown_info'
		};
		this.bindDefault(php);
		this.bridgeMuch(php);
		this.listenOver(function(data){
			if(!data.back){
				return this.errorPage();
			}
			data._CSSLinks = ['shop:back/back_shop'];
			data.pageTitle = '退店申请 - 美丽说';
			this.render('back/back_shop.html' , data);
		});
	}
};
```

[slide]
##ng页面的创建-ctrl
```js
	'agreement': function() {
		var mSelf = this;
		var php  = {

	    }
		this.bindDefault(php);
		this.bridgeMuch(php);
		this.listenOver(function(data){
			data.pageTitle = '申请网签';
	        data.moduleName = 'manage.agreement'; //模块名
	        data.moduleCtrl = ['intro', 'index', 'apply']; //模块下的controller
	        data.jsDefault 	= ['app', 'router', 'directives', 'factory'];//默认的JS文件
	        data.cssDefault = ['app', 'ctrl/index', 'ctrl/apply', 'ctrl/intro'];//默认的CSS文件
	        data.constant   = { 
	        	//JS全局变量，通过Meilishuo.constant获取   
	        }
	        mSelf.render('common/angular.html' , data);
		});
	},
```
[note]
1. 接口
2. 静态文件：js, css, ctrl
3. 模板壳angular.html
[/note]

[slide]
##ng页面的创建-less
```css
@import "../../../common/light/global.less";
.manage-agreement-intro{
	.light-info {
		color: @pink-dark;
	}
	.agreement-enter-tabel {
		th, td {
			text-align: center;
			line-height: 30px;
		}
		td {
			line-height: 50px;
		}
	}
	.permision-msg {
		display: block;
		max-width: 550px;
		margin: 0 auto;
	}
}
```
[note]
1. 对比less的目录结构
2. 只引入一个global文件
3. 代码简洁了许多
[/note]

[slide]
##ng页面的创建-js
1. app.js  启动angular和创建单页面的模块
2. router.js 负责单页面中页面的无刷新跳转
3. directives.js 负责自定义一些功能组件，代码复用
4. factory.js  提供服务，如工具方法，复杂的请求等。
5. ctrls  负责页面的数据和事件交互处理

[slide]
###ng页面的创建-app.js
```js
//1. 启动angular
angular.element(document).ready(function() {
    angular.bootstrap(document, ['manage.agreement']);
});

//2. 定义模块和声明依赖
angular.module('manage.agreement', [
        'ui.bootstrap',
        'ui.router'
    ])
    .run(['$rootScope', '$location', '$http', '$state', 
        function($rootScope, $location, $http, $state) {
        $rootScope.Meilishuo = Meilishuo;
    }])
```
[slide]
##ng页面的创建-router.js
```js

//定义路由 
angular.module('manage.agreement')
.config(['$stateProvider', '$urlRouterProvider',
  function($stateProvider, $urlRouterProvider) {
  
  $urlRouterProvider.otherwise("/intro");
  
  $stateProvider
    .state('intro', {
      url: "/intro",
      templateUrl: "/templates/manage/agreement/intro.html",
      controller: 'introCtrl'
    })
    .state('index', {
        url: "/index",
        templateUrl: "/templates/manage/agreement/index.html",
        controller: 'indexCtrl'
    })
    .state('apply', {
        url: "/apply",
        templateUrl: "/templates/manage/agreement/apply.html",
        controller: 'applyCtrl'
    })
}]);
```

[slide]
##ng页面创建-html
```html
<div class="content-wrapper">
	<!-- 查询表单 -->
	<div class="date-wrap">
		<input datepicker date-time="true" date-format="yyyy-MM-dd" 
		type="text" class="form-control" name="startDate" 
		ng-model="condition.startDate" id="startDate" />
		<span>到</span>
		<input datepicker date-time="true" date-format="yyyy-MM-dd" 
		type="text" class="form-control" name="endDate" 
		ng-model="condition.endDate" id="endDate" />
		<button class="btn btn-primary" ng-click="search()">确定</button>
	</div>

	<!-- 订单列表 -->
	<div class="order-list" >
		<table>
			<tr ng-repeat="order in orderList">
				<td>
					{{ order.order_id}}
				</td>
			</tr>
		</table>
	</div>
</div>
```


[slide]
##ng页面的创建-ctrl.js
```js
angular.module('manage.agreement')
  .controller('indexCtrl',[
    '$scope', '$http',
  function($scope, $http){
  	//1. 初始化 ——>php
  	(function init(){
		$http.post('/data/agreement/getInfo', params)
			.success(function(data){
				$scope.orderList = data.info;
			})
  	})()

  	//2. click 事件
  	$scope.search = function(){
  		$http.post('/data/agreement/submit', 
  			{
  				start: $scope.condition.startDate,
  				end:  $scope.condition.endDate
  			})
  			.success(function(data){
  			})
  	}
  }])
```


[slide]
##ng页面的创建-directives.js
```js
angular.module('manage.agreement') 
.directive('isUserInputValid', ['$filter', 'toastr', 'agreementUtilsFactory', function($filter, toastr, agreementUtilsFactory) {
    return {
        restrict: 'EA',  
        scope: true,
        link: function($scope, element, attrs) {
			//监听属性值变化
            $scope.$watch(attrs.ngModel, function(newValue, oldValue){
            	if(oldValue == newValue || oldValue == null) return;
				// some codes.....
            });
        }
    };
}])
```

[slide]
##ng页面的创建-factory.js
```js
angular.module('manage.agreement')
.factory('agreementUtilsFactory', [function(){
	var agreementUtilsFactory = {};

	// 四舍五入js版本
	agreementUtilsFactory.round10 = function(value, exp) {
	}

	//两数相加
	agreementUtilsFactory.numAdd = function(num1, num2) {
	};

	//两数相减
	agreementUtilsFactory.numSub = function(num1, num2) {
	};

	return agreementUtilsFactory;
}])
```

[slide]
##二、表单的校验
1. 简单校验

2. 自定义指令的校验

3. 校验的原理

[slide]
##1.angular提供的校验指令

* ng-required
* ng-maxlength / ng-minlength
* ng-pattern
* ng-change
* ng-trim

reference: http://docs.ngnice.com/api/ng/input/input%5Bemail%5D

[slide]
##2.表单项中的校验属性

|属性|类|描述|
|:-------------:|:-------------:|:-----:|
|$valid|	ng-valid | Boolean 告诉我们这一项当前基于你设定的规则是否验证通过|
|$invalid|	ng-invalid|	Boolean 告诉我们这一项当前基于你设定的规则是否验证未通过|
|$pristine|	ng-pristine| Boolean 如果表单或者输入框没有交互则为True|
|$dirty|	ng-dirty	|Boolean 如果表单或者输入框有修改则为True|
|$error|	ng-error	|Object  保存了表单的错误信息|
公式：formName.$valid / formName.fieldName.$valid
[note]
1. name的重要性，在control中注册
2. control中的parsers formatters
[/note]

[slide]
##3.自定义校验及原理
* $viewValue / $modelVaule
* $parsers / $formatters
* 优惠券的案列
[slide]
##三、angular启动流程


